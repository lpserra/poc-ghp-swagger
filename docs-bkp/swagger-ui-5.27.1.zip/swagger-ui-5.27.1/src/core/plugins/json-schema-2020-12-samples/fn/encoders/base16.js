/**
 * @prettier
 */
const encodeBase16 = (content) => Buffer.from(content).toString("hex")

export default encodeBase16
